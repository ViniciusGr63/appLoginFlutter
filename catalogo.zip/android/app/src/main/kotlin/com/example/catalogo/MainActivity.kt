package com.example.catalogo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
